<?php

/**
 * @package Mediboard\{PACKAGE}
 * @author  SAS OpenXtrem <dev@openxtrem.com>
{LICENSE}
 */

namespace {NAMESPACE};

use Ox\Core\Module\AbstractTabsRegister;


class CTabs{PACKAGE} extends AbstractTabsRegister
{
    public function registerAll(): void
    {
        $this->registerFile('configure', TAB_ADMIN, self::TAB_CONFIGURE);
    }
}
