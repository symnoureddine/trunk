<?php

/**
 * @package Mediboard\{PACKAGE}
 * @author  SAS OpenXtrem <dev@openxtrem.com>
{LICENSE}
 */

namespace {NAMESPACE};

use Ox\Core\CMbObject;

/**
 * My class
 */
class CMyClass extends CMbObject
{
    public $my_class_id;

      /** @var string */
      public $name;

      /**
       * @inheritDoc
       */
      function getSpec() {
        $spec = parent::getSpec();

        $spec->table = 'my_class';
        $spec->key   = 'my_class_id';

        return $spec;
      }

      /**
       * @inheritDoc
       */
      function getProps() {
        $props = parent::getProps();

        $props['name'] = 'str notNull maxLength|50 seekable show|0';

        return $props;
      }

      /**
       * @inheritDoc
       */
      function updateFormFields() {
        parent::updateFormFields();

        $this->_view = $this->name;
      }
}
