<?php

/**
 * @package Mediboard\{PACKAGE}
 * @author  SAS OpenXtrem <dev@openxtrem.com>
{LICENSE}
 */

namespace {NAMESPACE};

use Ox\Core\CSetup;

/**
 * {NAME_SHORT} Setup class
 */
class CSetup{PACKAGE} extends CSetup
{
    /**
    * @inheritDoc
    */
    function __construct() {
    parent::__construct();

    $this->mod_name = "{NAME_CANONICAL}";
    $this->makeRevision("0.0");
    $this->setModuleCategory("{MOD_CATEGORY}", "{MOD_PACKAGE}");

    $this->mod_version = "0.01";
    }
}
