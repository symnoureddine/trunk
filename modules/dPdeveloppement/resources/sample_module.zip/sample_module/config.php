<?php

/**
 * @package Mediboard\{PACKAGE}
 * @author  SAS OpenXtrem <dev@openxtrem.com>
{LICENSE}
 */

$dPconfig["{NAME_CANONICAL}"] = [];
