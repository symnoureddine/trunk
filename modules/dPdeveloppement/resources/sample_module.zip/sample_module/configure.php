<?php

/**
 * @package Mediboard\{PACKAGE}
 * @author  SAS OpenXtrem <dev@openxtrem.com>
 * {LICENSE}
 */

use Ox\Core\CCanDo;
use Ox\Core\CSmartyDP;

CCanDo::checkAdmin();

$smarty = new CSmartyDP();
$smarty->display("configure.tpl");
